#include<stdio.h>
struct card {
	char *face;
	char *suit;
};