#include<stdio.h>
typedef struct _scaed
{
	const char *face;
	const char *suit;
}Card;
/*struct card {
	const char *face;
	const char *suit;
};

typedef struct card Card;*/
